// src/api/baseUrl.js

// const BASE_URL ="https://0wljd5bz-3004.inc1.devtunnels.ms/api/s1";   

// const BASE_URL ="http://localhost:3004/api/s1";     



const BASE_URL ="http://localhost:5000/api/s1";
// const BASE_URL = "https://sarnic-new-16-fab-production-df8e.up.railway.app/api/s1";

export default BASE_URL;
 